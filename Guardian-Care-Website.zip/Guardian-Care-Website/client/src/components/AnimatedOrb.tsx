export default function AnimatedOrb({ size = 'large' }: { size?: 'large' | 'medium' | 'small' }) {
  const sizeClasses = {
    large: 'w-[800px] h-[800px]',
    medium: 'w-[600px] h-[600px]',
    small: 'w-[400px] h-[400px]'
  };

  return (
    <div className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none">
      <div className={`${sizeClasses[size]} relative`}>
        <div 
          className="absolute inset-0 rounded-full opacity-20 blur-3xl animate-pulse-glow"
          style={{
            background: 'radial-gradient(circle at 30% 30%, rgb(0, 200, 80) 0%, rgb(0, 150, 60) 25%, rgb(0, 100, 40) 50%, transparent 70%)',
            boxShadow: '0 0 60px rgba(0, 255, 100, 0.1)'
          }}
          data-testid="orb-glow-outer"
        />
        <div 
          className="absolute inset-[10%] rounded-full opacity-25 blur-2xl animate-rotate-slow"
          style={{
            background: 'radial-gradient(circle at 60% 40%, rgb(0, 180, 70) 0%, rgb(0, 140, 60) 30%, rgb(0, 100, 40) 60%, transparent 80%)',
            boxShadow: '0 0 40px rgba(0, 255, 100, 0.08)'
          }}
          data-testid="orb-glow-middle"
        />
        <div 
          className="absolute inset-[20%] rounded-full opacity-30 blur-xl animate-float"
          style={{
            background: 'radial-gradient(circle at 50% 50%, rgb(0, 200, 80) 0%, rgb(0, 160, 70) 40%, transparent 70%)',
            boxShadow: '0 0 30px rgba(0, 255, 100, 0.12)'
          }}
          data-testid="orb-glow-inner"
        />
        <div 
          className="absolute inset-[30%] rounded-full opacity-40 animate-glow-pulse"
          style={{
            background: 'radial-gradient(circle at 50% 50%, rgb(0, 220, 90) 0%, rgb(0, 180, 70) 50%, transparent 100%)',
            boxShadow: '0 0 20px rgba(0, 255, 100, 0.15)'
          }}
          data-testid="orb-core"
        />
      </div>

      <div className="absolute inset-0 flex items-center justify-center">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-primary rounded-full opacity-30 animate-pulse-glow"
            style={{
              left: `${50 + 35 * Math.cos((i * 2 * Math.PI) / 30)}%`,
              top: `${50 + 35 * Math.sin((i * 2 * Math.PI) / 30)}%`,
              animationDelay: `${i * 0.1}s`,
              boxShadow: '0 0 4px rgba(0, 255, 100, 0.3)'
            }}
            data-testid={`particle-${i}`}
          />
        ))}
      </div>
    </div>
  );
}
